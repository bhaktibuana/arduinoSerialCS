﻿namespace arduinoSerialCS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnl_connect = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_portName = new System.Windows.Forms.TextBox();
            this.tb_baudrate = new System.Windows.Forms.TextBox();
            this.btn_connect = new System.Windows.Forms.Button();
            this.lbl_conStats = new System.Windows.Forms.Label();
            this.arduinoSerialPort = new System.IO.Ports.SerialPort(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.tb_dataRecieve = new System.Windows.Forms.TextBox();
            this.pnl_connect.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_connect
            // 
            this.pnl_connect.Controls.Add(this.tb_dataRecieve);
            this.pnl_connect.Controls.Add(this.label3);
            this.pnl_connect.Controls.Add(this.lbl_conStats);
            this.pnl_connect.Controls.Add(this.btn_connect);
            this.pnl_connect.Controls.Add(this.tb_baudrate);
            this.pnl_connect.Controls.Add(this.tb_portName);
            this.pnl_connect.Controls.Add(this.label2);
            this.pnl_connect.Controls.Add(this.label1);
            this.pnl_connect.Location = new System.Drawing.Point(12, 12);
            this.pnl_connect.Name = "pnl_connect";
            this.pnl_connect.Size = new System.Drawing.Size(246, 215);
            this.pnl_connect.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "PORT";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Baudrate";
            // 
            // tb_portName
            // 
            this.tb_portName.Location = new System.Drawing.Point(110, 22);
            this.tb_portName.Name = "tb_portName";
            this.tb_portName.Size = new System.Drawing.Size(100, 20);
            this.tb_portName.TabIndex = 2;
            // 
            // tb_baudrate
            // 
            this.tb_baudrate.Location = new System.Drawing.Point(110, 48);
            this.tb_baudrate.Name = "tb_baudrate";
            this.tb_baudrate.Size = new System.Drawing.Size(100, 20);
            this.tb_baudrate.TabIndex = 3;
            // 
            // btn_connect
            // 
            this.btn_connect.Location = new System.Drawing.Point(43, 101);
            this.btn_connect.Name = "btn_connect";
            this.btn_connect.Size = new System.Drawing.Size(167, 23);
            this.btn_connect.TabIndex = 4;
            this.btn_connect.Text = "CONNECT";
            this.btn_connect.UseVisualStyleBackColor = true;
            this.btn_connect.Click += new System.EventHandler(this.btn_connect_Click);
            // 
            // lbl_conStats
            // 
            this.lbl_conStats.AutoSize = true;
            this.lbl_conStats.Location = new System.Drawing.Point(91, 81);
            this.lbl_conStats.Name = "lbl_conStats";
            this.lbl_conStats.Size = new System.Drawing.Size(73, 13);
            this.lbl_conStats.TabIndex = 5;
            this.lbl_conStats.Text = "Disconnected";
            // 
            // arduinoSerialPort
            // 
            this.arduinoSerialPort.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.arduinoSerialPort_DataReceived);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Data Recieve";
            // 
            // tb_dataRecieve
            // 
            this.tb_dataRecieve.Location = new System.Drawing.Point(110, 149);
            this.tb_dataRecieve.Name = "tb_dataRecieve";
            this.tb_dataRecieve.Size = new System.Drawing.Size(100, 20);
            this.tb_dataRecieve.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 253);
            this.Controls.Add(this.pnl_connect);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnl_connect.ResumeLayout(false);
            this.pnl_connect.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_connect;
        private System.Windows.Forms.Label lbl_conStats;
        private System.Windows.Forms.Button btn_connect;
        private System.Windows.Forms.TextBox tb_baudrate;
        private System.Windows.Forms.TextBox tb_portName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.IO.Ports.SerialPort arduinoSerialPort;
        private System.Windows.Forms.TextBox tb_dataRecieve;
        private System.Windows.Forms.Label label3;
    }
}

