﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arduinoSerialCS
{
    public partial class Form1 : Form
    {
        string getData;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn_connect_Click(object sender, EventArgs e)
        {
            if (btn_connect.Text == "CONNECT")
            {
                try
                {
                    arduinoSerialPort.PortName = tb_portName.Text;
                    arduinoSerialPort.BaudRate = Convert.ToInt32(tb_baudrate.Text);
                    arduinoSerialPort.Open();

                    if (arduinoSerialPort.IsOpen)
                    {
                        lbl_conStats.Text = "Connected";
                        btn_connect.Text = "DISCONNECT";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }
            }
            else
            {
                if (arduinoSerialPort.IsOpen)
                {
                    arduinoSerialPort.Close();
                    lbl_conStats.Text = "Disconnected";
                    btn_connect.Text = "CONNECT";
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (string port in System.IO.Ports.SerialPort.GetPortNames())
            {
                tb_portName.Text = port;
            }
        }

        private void arduinoSerialPort_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            getData = arduinoSerialPort.ReadLine();
            this.Invoke(new EventHandler(updateData));
        }

        private void updateData(object sender, EventArgs e)
        {
            string data = getData;
            tb_dataRecieve.Text = data;
        }
    }
}
